# Program to remove duplicate words from a given paragraph 
paragraph = input("Paste/Write your paragraph here :") 
lastWord = ""
currentWord = ""
newParagraph = "" 
for currentWord in paragraph.split(" ") :
    if lastWord != currentWord :
        newParagraph += currentWord
        newParagraph += " "    
    lastWord = currentWord    
print()
print("Paragraph without repeating words :")
print()
print(newParagraph)