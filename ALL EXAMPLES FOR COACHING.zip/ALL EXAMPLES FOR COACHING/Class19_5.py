# Give the lower limit range as static input and store it in a variable.
gvn_lowrlmt = int(input("Enter starting number:"))
# Give the upper limit range as static input and store it in another variable.
gvn_upprlmt = int(input("Enter ending numbers:"))
list=[]
# Loop from lower limit range to upper limit range using For loop.
for m in range(gvn_lowrlmt, gvn_upprlmt+1):
    # Inside the loop, give the iterator value as the number of the for loop.
    given_num = m
    # taking another variable to store the copy of original number
    # and initialize it with given num
    duplicate_num = given_num
    # Take a variable reverse_number and initialize it to null
    reverse_number = 0
    # using while loop to reverse the given number
    while (given_num > 0):
        # implementing the algorithm
        # getting the last digit
        remainder = given_num % 10
        reverse_number = (reverse_number * 10) + remainder
        given_num = given_num // 10
   # if duplicate_num and reverse_number are equal then it is palindrome
    if(duplicate_num == reverse_number):
      list.append(duplicate_num)

print("The palindrome numbers between", gvn_lowrlmt, "and", gvn_upprlmt, "are:")
print(list)