# Creating a list of prime numbers in a given range
 
# Function to check Prime
def isPrime(num):
  c=0
  for i in range(1,num+1):
      if num%i==0:
        c+=1
  if c==2:
    return True
  else:
    return False
 
start = int(input("Enter the lower limit :"))
end = int(input("Enter the upper limit :"))
 
primeList = []
 
for i in range(start , end):
    if isPrime(i):
        primeList.append(i)
 
print("List of prime numbers :")
print(primeList)

