import turtle
window=turtle.Screen()
pen=turtle.Turtle()
window.bgcolor("green")
window.title("Sejal")
window.mainloop()