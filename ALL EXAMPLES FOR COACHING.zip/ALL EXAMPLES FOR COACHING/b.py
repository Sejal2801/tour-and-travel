file = open("aboutPython.txt" , "r") 
# Reading content of the file  
fileContent = file.read() 
# Checking for numerical value 
flag = 0
lineNumber = 1
for i in fileContent :
    if i.isnumeric():
        flag=1
        break
    if i == "\n":
        lineNumber+=1 
print()
if flag == 1 : 
    print("Yes numerical value is present")   
    print("On line :" , lineNumber)
else :
    print("No numerical value exist in the program")
# Closing file
file.close()