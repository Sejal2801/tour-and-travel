# Opening file with python
 
file = open("m.txt" , "r")
 
# Reading content of the file 
 
fileContent = file.read()
 
incorrectWord = input("Enter the incorrect word :")
correctWord = input("Enter the correct word :")
 
newContent = ""
 
for i in fileContent.split(" ") :
    if i == incorrectWord:
        newContent += correctWord
 
    else:
        newContent += i
        
    newContent += " "
 
# Closing file
file.close()
 
# Opening file again to put new content
file = open("m.txt" , "w")
file.write(newContent)
file.close()
print()
print("Incorrect word replaced by correct word")
print()