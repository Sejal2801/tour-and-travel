# Opening file with python
 
file = open("about.txt" , "r")
 
# Reading content of the file 
 
fileContent = file.read()
 
prevCharacter = ""
currCharacter = ""
 
newContent = ""
 
for i in fileContent:
    
    currCharacter = i
    
    if prevCharacter.isnumeric() and currCharacter=="." :
        newContent = newContent[:-1]+"\n"+prevCharacter+currCharacter
 
    else:
        newContent += i
 
    prevCharacter = currCharacter
 
# Closing file
file.close()
 
# Opening file again to put new content
file = open("about.txt" , "w")
file.write(newContent)
file.close()
print()
print("Task Completed")
print()
