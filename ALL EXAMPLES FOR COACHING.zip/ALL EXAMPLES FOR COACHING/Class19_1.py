# Find the number of attempts
 
password_length = int(input("Enter the length of the password:"))
numbers_included = int(input("Enter total number of digits included :"))
 
maxPossiblePassword = 1
 
upperLimit = numbers_included
lowerLimit = upperLimit - password_length + 1
 
 
for i in range(lowerLimit , upperLimit + 1):
    maxPossiblePassword *= i 
 
print("Maximum number of attempts required :" , maxPossiblePassword)
